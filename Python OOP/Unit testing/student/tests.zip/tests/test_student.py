from project.student import Student
from unittest import TestCase, main


# class Student:
#     def __init__(self, name: str, courses=None):
#         if courses is None:
#             courses = {}
#         self.name = name
#         self.courses = courses  # {course_name: [notes]}
#
#     def enroll(self, course_name: str, notes, add_course_notes: str = ""):
#         if course_name in self.courses.keys():
#             [self.courses[course_name].append(x) for x in notes]
#             return "Course already added. Notes have been updated."
#
#         if add_course_notes == "Y" or add_course_notes == "":
#             self.courses[course_name] = notes
#             return "Course and course notes have been added."
#
#         self.courses[course_name] = []
#         return "Course has been added."
#
#     def add_notes(self, course_name, notes):
#         if course_name in self.courses.keys():
#             self.courses[course_name].append(notes)
#             return "Notes have been updated"
#         raise Exception("Cannot add notes. Course not found.")
#
#     def leave_course(self, course_name):
#         if course_name in self.courses.keys():
#             self.courses.pop(course_name)
#             return "Course has been removed"
#         raise Exception("Cannot remove course. Course not found.")


class StudentTest(TestCase):
    def test_if_student_initialization_is_correct_empty_courses(self):
        student = Student('Gosho')
        self.assertEqual({}, student.courses)
        self.assertEqual('Gosho', student.name)

    def test_if_student_initialization_is_correct(self):
        student = Student('Gosho', {'math': ['da', 'ne', 'moje bi']})
        self.assertEqual({'math': ['da', 'ne', 'moje bi']}, student.courses)
        self.assertEqual('Gosho', student.name)

    def test_enroll_when_course_name_in_courses(self):
        student = Student('Gosho', {'math': []})
        self.assertEqual("Course already added. Notes have been updated.", student.enroll('math', ['da', 'ne', 'moje bi']))
        self.assertEqual(['da', 'ne', 'moje bi'], student.courses['math'])
        self.assertEqual({'math': ['da', 'ne', 'moje bi']}, student.courses)

    def test_enroll_add_course_notes_equal_to_Y(self):
        student = Student('Gosho')
        self.assertEqual("Course and course notes have been added.", student.enroll('math', ['da', 'ne'], 'Y'))
        self.assertEqual({'math': ['da', 'ne']}, student.courses)

    def test_enroll_add_course_notes_equal_to_empty_string(self):
        student = Student('Gosho')
        self.assertEqual("Course and course notes have been added.", student.enroll('math', ['da', 'ne'], ''))
        self.assertEqual({'math': ['da', 'ne']}, student.courses)

    def test_enroll_add_course_notes_equal_to_string(self):
        student = Student('Gosho')
        self.assertEqual("Course has been added.", student.enroll('math', ['da', 'ne'], 'xa'))
        self.assertEqual({'math': []}, student.courses)

    def test_enroll_just_add_course(self):
        student = Student('Gosho')
        self.assertEqual("Course has been added.", student.enroll('math', [], 'dali'))
        self.assertEqual({'math': []}, student.courses)

    def test_add_notes_if_course_name_in_courses(self):
        student = Student('Gosho', {'math': ['da', 'ne']})
        self.assertEqual("Notes have been updated", student.add_notes('math', 'dali'))
        self.assertEqual({'math': ['da', 'ne', 'dali']}, student.courses)

    def test_add_not4es_if_course_name_not_in_courses(self):
        student = Student('Gosho')
        with self.assertRaises(Exception) as ex:
            student.add_notes('math', 'dali')
        self.assertEqual("Cannot add notes. Course not found.", str(ex.exception))

    def test_leave_course_if_name_in_courses(self):
        student = Student('Gosho', {'math': ['da', 'ne']})
        self.assertEqual("Course has been removed", student.leave_course('math'))
        self.assertEqual({}, student.courses)

    def test_leave_course_if_course_doesnt_exists(self):
        student = Student('Gosho')
        with self.assertRaises(Exception) as ex:
            student.leave_course('math')
        self.assertEqual("Cannot remove course. Course not found.", str(ex.exception))


if __name__ == '__main__':
    main()
